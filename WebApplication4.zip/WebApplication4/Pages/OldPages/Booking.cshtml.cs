using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication4.Pages.OldPages
{
    public class BookingModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
