using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Blogginlägg.Views
{
    public class LayoutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
