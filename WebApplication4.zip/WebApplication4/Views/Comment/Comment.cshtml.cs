using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Blogginlägg.Views.Comment
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
