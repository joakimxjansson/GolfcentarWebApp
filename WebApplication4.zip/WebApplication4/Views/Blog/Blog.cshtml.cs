using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Blogginlägg.Views.Forum
{
    public class PostDetailsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
